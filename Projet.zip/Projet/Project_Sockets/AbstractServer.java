public abstract class AbstractServer
{
	public abstract void connect(String ip);
} 